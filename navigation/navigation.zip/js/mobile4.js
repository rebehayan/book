$(document).ready(function(){
  const swiper = new Swiper('.md_recom', {
    slidesPerView:4,
    centeredSlides: true,
    loop:true
  });
});
